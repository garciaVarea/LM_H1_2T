document.getElementById('toggle-menu').addEventListener('click', function() {
    document.getElementById('navbar-sticky').classList.toggle('hidden');
});
